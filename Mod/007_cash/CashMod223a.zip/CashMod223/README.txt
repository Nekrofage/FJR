Hello.Please read this entire document. i'll try to keep it short, this is important stuff to know.

In order to install Cash Mod, 3 things are required:
	Edit various files
	Copy various files
	Run SQL queries

The edits to various files can be found in CashMod223.txt
	PLEASE BE VERY CAREFUL WHEN DOING THIS. Many people get it wrong the first time. Backup your files.
	You may want to consider installing EasyMod and using it to install Cash Mod.
The files needed to be copied are listed in CashMod223.txt
The SQL Queries that need to be run are
	a) listed in sql_223.txt, if you wish to run them manually.
	b) available in an automated sql installer which is provided.
		To use this,
		1) copy sql_install.php to your main ("root") phpBB directory
		2) load the page via your browser (you will be asked to log in if you have not already)
		3) delete the file.

If you are upgrading from CashMod 2.0.0 or 2.0.2, appropriate files are found in upgrade_202_223
	these applies to both 2.0.0 and 2.0.2
	NOTE: upgrading may change some of your settings back to default.
		Please make sure your settings are correct.

Help is available for this mod, to the best of my abilities, on 2 conditions:
	1) You have read this readme file.
		Yes, it sounds redundant, but many people won't bother,
		i refuse to take time to help those people who don't take the time to help themselves
	2) You have read and followed the advice on the support and troubleshooting posts located:
		http://www.phpbb.com/phpBB/viewtopic.php?t=94055#623226 and
		http://www.phpbb.com/phpBB/viewtopic.php?t=94055#625402
		i will do my best to keep these updated. Only ask for help if your error is not here

Other Mods:
	There are several mods out there that state that they require "Points System or Cash Mod"
	In the majority of these cases, they will require a currency with a database field 'user_points'
	They will not work without it. So to answer in advance,
		Q. "how do i get shop/lottery/bank/rpg mod to work with Cash Mod"
		A. "create a currency with the database field 'user_points'"
	If you wish to enquire about a particular mod, and whether it works with Cash Mod,
		firstly, most of them do.
		secondly, known mods that work with Cash Mod are listed here:
			http://www.phpbb.com/phpBB/viewtopic.php?t=94055#655651
		if the mod in question is not listed, feel free to ask, otherwise, use your head
		(sorry, i'm just tired of constantly getting "does this work with shop/bank/lottery mod?" --- YES!)

Help requests that obviously fail these conditions will be ignored, or possibly deleted.
Sorry if this sounds harsh. When in doubt, use your common sense. I know most of you will :-)

I hope you enjoy this Mod. :-)
Cheers
	Xore
