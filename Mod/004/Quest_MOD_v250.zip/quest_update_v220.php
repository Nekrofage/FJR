<?php
/***************************************************************************
 *                            quest_update_v220.php
 *                           -----------------------
 *		                v2.2.0 Update file
 *
 *		Quest MOD made and (c) by Guido "Nuladion" Kessels
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path='./';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if( !$userdata['session_logged_in'] )
{
	header('Location: ' . append_sid("login.$phpEx?redirect=quest_update_v220.php", true));
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}

if( !strstr($dbms, "mysql") )
{
    if( !isset($bypass) )
    {
        $message = 'This mod has only been tested on MySQL and may only work on MySQL.<br />';
        $message .= 'Click <a href="quest_update_v220.php?bypass=true">here</a> to install anyways.';
        message_die(GENERAL_MESSAGE, $message);
    }
}

$sql = array();

$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type,config_isradio,config_radio_choices) VALUES ('imagetype','gif','map','1','gif,jpeg')";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type,config_isradio,config_radio_choices) VALUES ('exportmaps','Yes','map','1','Yes,No')";

$dat = array(
		'Updating Settings table',
		'Updating Settings table'
);
$sql_count = count($sql);

echo "<html>\n";
echo "<body>\n";

for($i = 0; $i < $sql_count; $i++) {
	echo "" . $dat[$i];
	flush();

	if ( !$db->sql_query($sql[$i]) )
	{
		$errored = true;
		$error = $db->sql_error();
		echo "... <b><font color=\"FF0000\">FAILED</font></b><BR />Error Message:<i>" . $error['message'] . "</i><br />\n";
	}
	else
	{
		echo "... <b><font color=\"007700\">COMPLETED</font></b><br />\n";
	}
}

if( $errored ) {
    $message = "The update was <b>not</b> successful. Please try again!<br />If the problem persists, please post in the Quest MOD topic @ <a href=\"http://mods.best-dev.com\" target=\"_blank\">http://mods.best-dev.com</a> or <a href=\"http://www.phpbb.com\" target=\"_blank\">http://www.phpbb.com</a>";
}
else {
    $message = "The update has been completed succesfully.<br />Make sure to delete this update file!<br />
<br />
<b>Have fun!</b><br />
<br />
- Nuladion";
}

echo "\n<br />\n<b>Finished!</b><br />\n";
echo $message . "<br />\n";
echo "</body>\n";
echo "</html>\n";
exit();

?>