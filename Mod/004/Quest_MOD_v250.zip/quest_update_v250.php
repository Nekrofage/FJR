<?php
/***************************************************************************
 *                            quest_update_v250.php
 *                           -----------------------
 *		                v2.5.0 Update file
 *
 *		Quest MOD made and (c) by Guido "Nuladion" Kessels
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path='./';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

// UPDATE FILE!
$file = 'quest_update_v250.php';

if( !$userdata['session_logged_in'] )
{
	header('Location: ' . append_sid("login.$phpEx?redirect=".$file, true));
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}

if( !strstr($dbms, "mysql") )
{
    if( !isset($bypass) )
    {
        $message = 'This mod has only been tested on MySQL and may only work on MySQL.<br />';
        $message .= 'Click <a href="'.$file.'?bypass=true">here</a> to install anyways.';
        message_die(GENERAL_MESSAGE, $message);
    }
}

echo "<html>\n";
echo "<body>\n";

$sql = array();
$dat = array();

// Lets INSTALL/UPDATE!

// Check if xxx_nulmods already exist!
echo "Check if ".$table_prefix."nulmods table exists...";
$check = mysql_query("SELECT * FROM ".$table_prefix."nulmods LIMIT 0,1");
if($check) { 
	// Table exists! -- Add Quest MOD info! 
	echo "<b><font color=\"007700\">YES</font></b><br />\n";
	$dat[] = "Inserting Quest MOD info";
	$sql[] = "INSERT INTO `".$table_prefix."nulmods` (title,version) VALUES ('Quest MOD','2.5.0')";
}
else {
	// Table doesn't exist! -- Create it and add Quest MOD info!
	echo "<b><font color=\"orange\">NO</font></b><br />\n";
	$dat[] = "Creating ".$table_prefix."nulmods table";
	$sql[] = "CREATE TABLE `".$table_prefix."nulmods` (
	  `id` int(10) unsigned NOT NULL auto_increment,
	  `title` MEDIUMTEXT NOT NULL,
	  `version` MEDIUMTEXT NOT NULL,
	  PRIMARY KEY  (`id`)
	)";
	
	$dat[] = "Inserting Quest MOD info";
	$sql[] = "INSERT INTO `".$table_prefix."nulmods` (title,version) VALUES ('Quest MOD','2.5.0')";
}

$sql_count = count($sql);

for($i = 0; $i < $sql_count; $i++) {
	echo "" . $dat[$i];
	flush();

	if ( !$db->sql_query($sql[$i]) )
	{
		$errored = true;
		$error = $db->sql_error();
		echo "... <b><font color=\"FF0000\">FAILED</font></b><BR />Error Message: <i>" . $error['message'] . "</i><br />\n";
	}
	else
	{
		echo "... <b><font color=\"007700\">COMPLETED</font></b><br />\n";
	}
}

if( $errored ) {
    $message = "The update was <b>not</b> successful! <br />
		<u>Do not reload this page</u>, or your database will be modified twice, which is <u>not</u> good! <br />
		Please post in the <a href=\"http://mods.best-dev.com/viewtopic.php?t=983\" target=\"_blank\">Quest MOD thread</a>!<br />
		If you want good and fast support, please make sure to include all the errors messages you might've gotten while updating!
		";
}
else {
    $message = "The update has been completed succesfully.<br />
		Make sure to delete this update file!<br />
		<br />
		<b>Have fun!</b><br />
		<br />
		- Nuladion
		";
}

echo "\n<br />\n<b>Finished!</b><br />\n";
echo $message . "<br />\n";
echo "</body>\n";
echo "</html>\n";
exit();

?>