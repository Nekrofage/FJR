<?php
/***************************************************************************
 *                            quest_update_v240.php
 *                           -----------------------
 *		                v2.4.0 Update file
 *
 *		Quest MOD made and (c) by Guido "Nuladion" Kessels
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path='./';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

// UPDATE FILE!
$file = 'quest_update_v240.php';

if( !$userdata['session_logged_in'] )
{
	header('Location: ' . append_sid("login.$phpEx?redirect=".$file, true));
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}

if( !strstr($dbms, "mysql") )
{
    if( !isset($bypass) )
    {
        $message = 'This mod has only been tested on MySQL and may only work on MySQL.<br />';
        $message .= 'Click <a href="'.$file.'?bypass=true">here</a> to install anyways.';
        message_die(GENERAL_MESSAGE, $message);
    }
}

$sql = array();
$dat = array();

// Lets INSTALL/UPDATE!

// UNCOMMENT THIS IF SOMETHING WENT WRONG!
// [START]
//	$dat[] = 'Getting rid of inserted rows in the "quest_settings" table';
//	$sql[] = "DELETE FROM `".$table_prefix."quest_settings` WHERE config_name = 'chat' OR config_name = 'chat_show' OR config_name = 'chat_away' OR config_name = 'chat_offline' OR config_name = 'chat_refresh' OR config_name ='chat_refreshlist' ";
// [END]

$dat[] = 'Updating "quest_settings" table';
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` 
		(config_name,config_value,config_type,config_isradio,config_radio_choices) 
		VALUES 
		('chat','','header','',''), 
		('chat_show','80','chat','',''), 
		('chat_away','180','chat','',''), 
		('chat_offline','300','chat','',''), 
		('chat_refresh','10','chat','',''), 
		('chat_refreshlist','10','chat','','')
";

$dat[] = 'Creating "quest_chat" table';
$sql[] = "CREATE TABLE `".$table_prefix."quest_chat` (
	  `message_id` int(10) unsigned NOT NULL auto_increment,
	  `poster` int(10) unsigned NOT NULL default '',
	  `message` mediumtext NOT NULL,
	  `timestamp` int(10) unsigned NOT NULL,
	  PRIMARY KEY  (`message_id`)
)";
$dat[] = 'Creating "quest_chat_session" table';
$sql[] = "CREATE TABLE `".$table_prefix."quest_chat_session` (
	  `user` int(10) unsigned NOT NULL default '',
	  `time` int(10) NOT NULL default '0',
	  `status` varchar(10) NOT NULL,
	  PRIMARY KEY  (`user`)
)";

$dat[] = 'Adding answer1_url field to "quest_scripts" table';
$sql[] = "ALTER TABLE `".$table_prefix."quest_scripts` ADD answer1_url MEDIUMTEXT";
$dat[] = 'Adding answer2_url field to "quest_scripts" table';
$sql[] = "ALTER TABLE `".$table_prefix."quest_scripts` ADD answer2_url MEDIUMTEXT";
$dat[] = 'Adding answer3_url field to "quest_scripts" table';
$sql[] = "ALTER TABLE `".$table_prefix."quest_scripts` ADD answer3_url MEDIUMTEXT";
$dat[] = 'Adding answer4_url field to "quest_scripts" table';
$sql[] = "ALTER TABLE `".$table_prefix."quest_scripts` ADD answer4_url MEDIUMTEXT";


$sql_count = count($sql);

echo "<html>\n";
echo "<body>\n";

for($i = 0; $i < $sql_count; $i++) {
	echo "" . $dat[$i];
	flush();

	if ( !$db->sql_query($sql[$i]) )
	{
		$errored = true;
		$error = $db->sql_error();
		echo "... <b><font color=\"FF0000\">FAILED</font></b><BR />Error Message: <i>" . $error['message'] . "</i><br />\n";
	}
	else
	{
		echo "... <b><font color=\"007700\">COMPLETED</font></b><br />\n";
	}
}

if( $errored ) {
    $message = "The update was <b>not</b> successful! <br />
		<u>Do not reload this page</u>, or your database will be modified twice, which is <u>not</u> good! <br />
		Please post in the <a href=\"http://mods.best-dev.com/viewtopic.php?t=983\" target=\"_blank\">Quest MOD thread</a>!<br />
		If you want good and fast support, please make sure to include all the errors messages you might've gotten while updating!
		";
}
else {
    $message = "The update has been completed succesfully.<br />
		Make sure to delete this update file!<br />
		<br />
		<b>Have fun!</b><br />
		<br />
		- Nuladion
		";
}

echo "\n<br />\n<b>Finished!</b><br />\n";
echo $message . "<br />\n";
echo "</body>\n";
echo "</html>\n";
exit();

?>