<?php
/***************************************************************************
 *                            quest_update_v230.php
 *                           -----------------------
 *		                v2.3.0 Update file
 *
 *		Quest MOD made and (c) by Guido "Nuladion" Kessels
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path='./';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if( !$userdata['session_logged_in'] )
{
	header('Location: ' . append_sid("login.$phpEx?redirect=quest_update_v230.php", true));
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}

if( !strstr($dbms, "mysql") )
{
    if( !isset($bypass) )
    {
        $message = 'This mod has only been tested on MySQL and may only work on MySQL.<br />';
        $message .= 'Click <a href="quest_update_v230.php?bypass=true">here</a> to install anyways.';
        message_die(GENERAL_MESSAGE, $message);
    }
}

$sql = array();

$sql[] = "CREATE TABLE `".$table_prefix."quest_sprite_images` (
	  `id` int(10) unsigned NOT NULL auto_increment,
	  `name` mediumtext NOT NULL,
	  `image` mediumtext NOT NULL,
	  `layer` int(10) NOT NULL default '0',
	  `itemneeded` mediumtext NOT NULL,
	  `dontshowlayer` int(10) NOT NULL default '',
	  PRIMARY KEY  (`id`)
)";

$sql[] = "INSERT INTO `".$table_prefix."quest_sprite_images` (`name`, `image`, `layer`, `itemneeded`, `dontshowlayer`) VALUES
	('Cat Ears', 'Cat Ears.gif', 5, '', 0),
	('Body', 'Body.gif', 4, '', 0),
	('Brown', 'Red1.gif', 1, '', 0),
	('Blond', 'Blond1.gif', 1, '', 0),
	('Coat', 'Green Coat.gif', 2, '', 0),
	('Mantle', 'Black Mantle.gif', 2, '', 0),
	('Face1', 'Head1.gif', 3, '', 0),
	('Face2', 'Head2.gif', 3, '', 0),
	('Iron Helmet', 'Iron Helmet.gif', 5, '', 1)
";


$sql[] = "CREATE TABLE `".$table_prefix."quest_sprite_layers` (
	  `id` int(10) unsigned NOT NULL auto_increment,
	  `name` mediumtext NOT NULL,
	  `position` tinyint(3) NOT NULL default '0',
	  `compulsive` tinyint(1) NOT NULL default '0',
	  PRIMARY KEY  (`id`)
)";

$sql[] = "INSERT INTO `".$table_prefix."quest_sprite_layers` (`name`, `position`, `compulsive`) VALUES
		('Hair', 4, 0),
		('Clothing', 3, 1),
		('Face', 2, 1),
		('Body', 1, 1),
		('Helmet', 5, 0)
";

$sql[] = "CREATE TABLE `".$table_prefix."quest_sprite_userchars` (
	  `id` int(10) unsigned NOT NULL auto_increment,
	  `user` int(10) unsigned NOT NULL default '',
	  `Body` mediumtext NOT NULL,
	  `Face` mediumtext NOT NULL,
	  `Clothing` mediumtext NOT NULL,
	  `Hair` mediumtext NOT NULL,
	  `Helmet` mediumtext NOT NULL,
	  PRIMARY KEY  (`id`)
)";

$dat = array(
		'Creating "quest_sprite_layers" table',
		'Inserting Layers',
		'Creating "quest_sprite_images" table',
		'Inserting Images',
		'Creating "quest_sprite_userchars" table'
);
$sql_count = count($sql);

echo "<html>\n";
echo "<body>\n";

for($i = 0; $i < $sql_count; $i++) {
	echo "" . $dat[$i];
	flush();

	if ( !$db->sql_query($sql[$i]) )
	{
		$errored = true;
		$error = $db->sql_error();
		echo "... <b><font color=\"FF0000\">FAILED</font></b><BR />Error Message:<i>" . $error['message'] . "</i><br />\n";
	}
	else
	{
		echo "... <b><font color=\"007700\">COMPLETED</font></b><br />\n";
	}
}

if( $errored ) {
    $message = "The update was <b>not</b> successful. Please try again!<br />If the problem persists, please post in the Quest MOD topic @ <a href=\"http://mods.best-dev.com\" target=\"_blank\">http://mods.best-dev.com</a> or <a href=\"http://www.phpbb.com\" target=\"_blank\">http://www.phpbb.com</a>";
}
else {
    $message = "The update has been completed succesfully.<br />Make sure to delete this update file!<br />
<br />
<b>Have fun!</b><br />
<br />
- Nuladion";
}

echo "\n<br />\n<b>Finished!</b><br />\n";
echo $message . "<br />\n";
echo "</body>\n";
echo "</html>\n";
exit();

?>