<?php
/***************************************************************************
 *                            quest_update_v210.php
 *                           -----------------------
 *		                v2.1.0 Update file
 *
 *		Quest MOD made and (c) by Guido "Nuladion" Kessels
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path='./';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if( !$userdata['session_logged_in'] )
{
	header('Location: ' . append_sid("login.$phpEx?redirect=quest_update_v210.php", true));
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}

if( !strstr($dbms, "mysql") )
{
    if( !isset($bypass) )
    {
        $message = 'This mod has only been tested on MySQL and may only work on MySQL.<br />';
        $message .= 'Click <a href="quest_update_v210.php?bypass=true">here</a> to install anyways.';
        message_die(GENERAL_MESSAGE, $message);
    }
}

$sql = array();

$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type) VALUES ('scripts','','header')";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type) VALUES ('script_length','50','scripts')";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type) VALUES ('default_map_height','6','map')";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type) VALUES ('default_map_width','6','map')";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type) VALUES ('users','','header')";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type) VALUES ('default_map','1','users')";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type) VALUES ('default_map_x','1','users')";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type) VALUES ('default_map_y','1','users')";
$sql[] = "ALTER TABLE `".$table_prefix."quest_settings` ADD config_isradio TINYINT(1) NOT NULL DEFAULT '0' ";
$sql[] = "ALTER TABLE `".$table_prefix."quest_settings` ADD config_radio_choices MEDIUMTEXT NOT NULL DEFAULT '' ";
$sql[] = "INSERT INTO `".$table_prefix."quest_settings` (config_name,config_value,config_type,config_isradio,config_radio_choices) VALUES ('grid','Yes','map','1','Yes,No')";
$sql[] = "ALTER TABLE `".$table_prefix."quest_teleports` ADD url MEDIUMTEXT NOT NULL DEFAULT '' ";

$sql[] = "CREATE TABLE `".$table_prefix."quest_npcs` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `npc_name` mediumtext NOT NULL,
  `npc_description` mediumtext NOT NULL,
  `npc_action` mediumtext NOT NULL,
  `npc_portrait` mediumtext NOT NULL,
  `npc_image` mediumtext NOT NULL,
  `npc_map_id` int(10) NOT NULL,
  `npc_map_x` mediumint(9) NOT NULL,
  `npc_map_y` mediumint(9) NOT NULL,
  `npc_script` mediumint(9) NOT NULL,
  PRIMARY KEY  (`id`)
)";

$sql[] = "CREATE TABLE `".$table_prefix."quest_scripts` (
  `script_id` int(10) unsigned NOT NULL auto_increment,
  `npc_id` int(10) unsigned NOT NULL,
  `text` mediumtext NOT NULL,
  `answer1_text` mediumtext NOT NULL,
  `answer1_script` mediumtext NOT NULL,
  `answer2_text` mediumtext NOT NULL,
  `answer2_script` mediumtext NOT NULL,
  `answer3_text` mediumtext NOT NULL,
  `answer3_script` mediumtext NOT NULL,
  `answer4_text` mediumtext NOT NULL,
  `answer4_script` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `action` mediumtext NOT NULL,
  PRIMARY KEY  (`script_id`)
)";

$dat = array(
		'Updating Settings table',
		'Updating Settings table',
		'Updating Settings table',
		'Updating Settings table',
		'Updating Settings table',
		'Updating Settings table',
		'Updating Settings table',
		'Updating Settings table',
		'Altering Settings table',
		'Altering Settings table',
		'Updating Settings table',
		'Altering Teleports table',
		'Creating table "quest_npcs"',
		'Creating table "quest_scripts"'

);
$sql_count = count($sql);

echo "<html>\n";
echo "<body>\n";

for($i = 0; $i < $sql_count; $i++) {
	echo "" . $dat[$i];
	flush();

	if ( !$db->sql_query($sql[$i]) )
	{
		$errored = true;
		$error = $db->sql_error();
		echo "... <b><font color=\"FF0000\">FAILED</font></b><BR />Error Message:<i>" . $error['message'] . "</i><br />\n";
	}
	else
	{
		echo "... <b><font color=\"007700\">COMPLETED</font></b><br />\n";
	}
}

if( $errored ) {
    $message = "The update was <b>not</b> successful. Please try again!<br />If the problem persists, please post in the Quest MOD topic @ <a href=\"http://mods.best-dev.com\" target=\"_blank\">http://mods.best-dev.com</a>";
}
else {
    $message = "The update has been completed succesfully.<br />Make sure to delete this update file!<br />
<br />
<b>IMPORTANT:</b><br />
Before you can use the new Quest MOD version, you need to make a folder called <b>map_maps</b> in your <i><root>/images/</i> folder, so you have a <b>images/map_maps/</b> folder! Make sure you <b>CHMOD it to 777</b> too!<br />
After that, go to the Admin Panels >> Map Editor and load & Export all your maps (if you made some)! This is necessary, otherwise your users won't see the new maps on their screen!<br />
<br />
<b>Have fun!</b><br />
<br />
- Nuladion";
}

echo "\n<br />\n<b>Finished!</b><br />\n";
echo $message . "<br />\n";
echo "</body>\n";
echo "</html>\n";
exit();

?>