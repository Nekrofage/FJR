<?php
/***************************************************************************
 *                               db_update.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *   project              : http://sourceforge.net/projects/dbgenerator
 *   Website              : http://freakingbooty.no-ip.com/ & http://www.rapiddr3am.net
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=db_update.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<table width="100%" cellspacing="1" cellpadding="2" border="0" class="forumline">';
echo '<tr><th>Updating the database</th></tr><tr><td><span class="genmed"><ul type="circle">';


$sql = array();
$sql[] = "DROP TABLE IF EXISTS " . $table_prefix . "userhouses";
$sql[] = "CREATE TABLE " . $table_prefix . "userhouses (
  owner_id int(8) NOT NULL default '0',
  house_type smallint(2) NOT NULL default '0',
  house_inventory text,
  rpg_id int(8) NOT NULL default '0',
  rpg_description text,
  rpg_prize int(16) NOT NULL default '0',
  PRIMARY KEY  (owner_id)
) TYPE=MyISAM";
$sql[] = "DROP TABLE IF EXISTS " . $table_prefix . "houses";
$sql[] = "CREATE TABLE " . $table_prefix . "houses (
  house_type smallint(2) NOT NULL default '0',
  house_name varchar(255) NOT NULL default '',
  house_front varchar(255) NOT NULL default '',
  house_bg varchar(255) NOT NULL default '',
  house_prize int(16) NOT NULL default '0',
  house_width int(8) NOT NULL default '0',
  house_cellwidth int(8) NOT NULL default '20',
  house_cellwidthnumber int(8) NOT NULL default '0',
  house_height int(8) NOT NULL default '0',
  house_cellheight int(8) NOT NULL default '20',
  house_cellheightnumber int(8) NOT NULL default '0',
  house_special smallint(2) NOT NULL default '0',
  house_floor text,
  house_wall text,
  house_fw text,
  house_garden text,
  PRIMARY KEY  (house_type)
) TYPE=MyISAM";
$sql[] = "DROP TABLE IF EXISTS " . $table_prefix . "house_settings";
$sql[] = "CREATE TABLE " . $table_prefix . "house_settings (
  var smallint(2) NOT NULL default '1',
  enabled smallint(2) NOT NULL default '0',
  sell int(3) NOT NULL default '50',
  shop_1 varchar(255) NOT NULL default '',
  home_title varchar(255) NOT NULL default '',
  row_display int(3) NOT NULL default '4',
  column_display int(3) NOT NULL default '4',
  shop_2 varchar(255) NOT NULL default '',
  PRIMARY KEY  (var)
) TYPE=MyISAM";
$sql[] = "INSERT INTO " . $table_prefix . "house_settings (var, enabled, sell, shop_1, home_title, row_display, column_display, shop_2) VALUES (1, 1, 50, '', '', 4, 4, '')";
$sql[] = "INSERT INTO " . $table_prefix . "houses (house_type, house_name, house_front, house_bg, house_prize, house_width, house_cellwidth, house_cellwidthnumber, house_height, house_cellheight, house_cellheightnumber, house_special, house_floor, house_wall, house_fw, house_garden) VALUES (1, 'Small House', 'small house.gif', 'small-house-interrior.gif', 10000, 300, 50, 6, 400, 50, 8, 0, ',15,16,20,21,22,23,26,27,28,29', ',8,11,38,41', ',14,17', '')";
$sql[] = "INSERT INTO " . $table_prefix . "houses (house_type, house_name, house_front, house_bg, house_prize, house_width, house_cellwidth, house_cellwidthnumber, house_height, house_cellheight, house_cellheightnumber, house_special, house_floor, house_wall, house_fw, house_garden) VALUES (2, 'Medium House', 'medium house.gif', 'medium house interrior.gif', 500000, 600, 50, 12, 450, 50, 9, 0, NULL, NULL, NULL, NULL)";
$sql[] = "INSERT INTO " . $table_prefix . "config VALUES ('use_adr_shops_in_house', '0')";
$sql[] = "INSERT INTO " . $table_prefix . "config VALUES ('house_use_in_adr', '0')";

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successfull</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>End</th></tr><tr><td><span class="genmed">Installation is now finished. Please be sure to delete this file now.<br />If you have run into any errors, please visit the <a href="http://www.phpbbsupport.co.uk" target="_phpbbsupport">phpBBSupport.co.uk</a> and ask someone for help.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Have a nice day</a></span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>
