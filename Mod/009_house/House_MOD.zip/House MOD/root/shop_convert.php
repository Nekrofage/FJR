<?php
define('IN_PHPBB', true);
define('IN_ADR_SHOPS', true);
define('IN_ADR_CHARACTER', true);
$phpbb_root_path = './';
//
// phpBB related files
//
include_once( $phpbb_root_path . 'extension.inc' );
include_once( $phpbb_root_path . 'common.' . $phpEx );
//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);

if ( !$userdata['session_logged_in'] )
{
	$redirect = 'index.php';
	header('Location: ' . append_sid("login.$phpEx?redirect=$redirect", true));
}
//
// End session management
//
include_once($phpbb_root_path . 'adr/includes/adr_constants.'.$phpEx);
include_once($phpbb_root_path . 'adr/includes/adr_global.'.$phpEx);

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$template->set_filenames(array(
	'body' => 'shop_convert_body.tpl')
);

// Start Add New Shop Items from Shops MOD into ADR Shops
// Determine the new start id for the items
$sql = "SELECT item_id
		FROM ". ADR_SHOPS_ITEMS_TABLE ."
		WHERE item_owner_id = '1'
		ORDER BY item_id
		DESC LIMIT 1";
$result = $db->sql_query($sql);
if (!$result)
	message_die(GENERAL_ERROR, 'Could not obtain ADR item information', '', __LINE__, __FILE__, $sql);
$data = $db->sql_fetchrow($result);

$new_item_id = $data['item_id'] + 1;

$sql = "SELECT * from " . SHOPITEMS_TABLE . "
		WHERE furniture_type='1'
			OR furniture_type='2'
			OR furniture_type='3'
			OR furniture_type='4'
		ORDER by name";
if ( !($result = $db->sql_query($sql)) ) { message_die(GENERAL_MESSAGE, 'Fatal Error getting Shopitems'); }
$items = $db->sql_fetchrowset($result);

$sql = "SELECT * from ".HOUSE_SETTINGS_TABLE."
		WHERE var=1";
if ( !($result = $db->sql_query($sql)) ) { message_die(GENERAL_MESSAGE, 'Fatal Error Getting House Configs!'); }
$crow = mysql_fetch_array($result);

$sql = "SELECT * FROM  " . ADR_GENERAL_TABLE ;
if (!$result = $db->sql_query($sql))
{
	message_die(GENERAL_MESSAGE, $lang['Adr_character_lack']);
}
while( $row = $db->sql_fetchrow($result) )
{
	$adr_general[$row['config_name']] = $row['config_value'];
}

$shop_mod_shop_1 = $crow['shop_1'];
$shop_mod_shop_2 = $crow['shop_2'];
$adr_shop_1 = $adr_general['furniture_shop_id'];
$adr_shop_2 = $adr_general['garden_shop_id'];

$floor_item_count = 0;
$wall_item_count = 0;
$floor_wall_item_count = 0;
$garden_item_count = 0;
$error_item_count = 0;
$total_floor_item_count = 0;
$total_wall_item_count = 0;
$total_floor_wall_item_count = 0;
$total_garden_item_count = 0;
$total_error_item_count = 0;
$error = false;

for ($x = 0; $x < count($items); $x++)
{
	$item_id		= $new_item_id + $x;
	$item_icon		= 'house/' . trim($items[$x]['name']) . '.gif';
	$item_name		= addslashes(stripslashes($items[$x]['sdesc']));
	$item_desc		= addslashes(stripslashes($items[$x]['ldesc']));
	$item_price		= $items[$x]['cost'];
	if ( $items[$x]['shop'] == $shop_mod_shop_1 )
	{
		$item_store_id = $adr_shop_1;
	}
	else if ( $items[$x]['shop'] == $shop_mod_shop_2 )
	{
		$item_store_id = $adr_shop_2;
	}
	else
	{
		$error_item_count = $error_item_count + 1;
		$error = true;
	}
	$item_type		= $items[$x]['furniture_type'] + 71;
	if ( $item_type == 72 )
	{
		$floor_item_count = $floor_item_count + 1;
		$total_floor_item_count = $total_floor_item_count + 1;
	}
	else if  ( $item_type == 73 )
	{
		$wall_item_count = $wall_item_count + 1;
		$total_wall_item_count = $total_wall_item_count + 1;
	}
	else if  ( $item_type == 74 )
	{
		$floor_wall_item_count = $floor_wall_item_count + 1;
		$total_floor_wall_item_count = $total_floor_wall_item_count + 1;
	}
	else if  ( $item_type == 75 )
	{
		$garden_item_count = $garden_item_count + 1;
		$total_garden_item_count = $total_garden_item_count + 1;
	}
	else
	{
		$error_item_count = $error_item_count + 1;
		$total_error_item_count = $total_error_item_count + 1;
		$error = true;
	}

	if ( !$error )
	{
		$sql = "INSERT INTO " . ADR_SHOPS_ITEMS_TABLE . "
				( item_id , item_owner_id , item_type_use , item_name , item_desc , item_icon , item_price , item_store_id , item_duration )
				VALUES ( $item_id , 1 , $item_type , '" . str_replace("\'", "''", $item_name) . "', '" . str_replace("\'", "''", $item_desc) . "' , '" . str_replace("\'", "''", $item_icon) . "' ,$item_price , $item_store_id , 1 )";
		if (!$db->sql_query($sql))
			message_die(GENERAL_ERROR, "Couldn't insert ADR Shop new item", "", __LINE__, __FILE__, $sql);
//echo "<br />Item ID=".$item_id."<br />Item Type=".$item_type."<br />Item Name=".$item_name;
	}
	else
	{
		$error = false;
	}
}
$template->assign_vars(array(
	'L_ITEMS_PROCESSED' => 'The following Shop MOD items were processed:',
	'L_PROCESSING_COMPLETE' => 'All Shop MOD Shop Items processed.',
	'L_ALL_PROCESSING_COMPLETE' => 'All User Items and Shop MOD Items processed.',
	'L_FLOOR_ITEMS_COUNT' => ( $floor_item_count > 0 ) ? 'We processed ' . number_format($floor_item_count) . ' Floor Items' : '',
	'L_WALL_ITEMS_COUNT' => ( $wall_item_count > 0 ) ? 'We processed ' . number_format($wall_item_count) . ' Wall Items' : '',
	'L_FLOOR_WALL_ITEMS_COUNT' => ( $floor_wall_item_count > 0 ) ? 'We processed ' . number_format($floor_wall_item_count) . ' Floor Base Of Wall Items' : '',
	'L_GARDEN_ITEMS_COUNT' => ( $garden_item_count > 0 ) ? 'We processed ' . number_format($garden_item_count) . ' Garden Items' : '',
	'L_ERROR_ITEMS_COUNT' => ( $error_item_count > 0 ) ? 'We didn\'t process ' . number_format($error_item_count) . ' Non-House Items' : '',
));
	
// End New Shop Items from Shops MOD into ADR Shops

// Start Convert House MOD User Items from Shop MOD Items to ADR Shop Items
$csql = "SELECT u.username , u.user_items , u.user_id , h.owner_id , h.house_inventory FROM " . USERS_TABLE . " u
		LEFT JOIN " . USER_HOUSE_TABLE . " h ON ( user_id = owner_id )
		WHERE user_id > 1 ";
if( !($cresult = $db->sql_query($csql) ))
{
	message_die(GENERAL_ERROR, 'Could not obtain users information', "", __LINE__, __FILE__, $csql);
}
$users = $db->sql_fetchrowset($cresult);

for ( $i = 0 ; $i < count($users) ; $i ++ )
{
	$floor_item_count = 0;
	$wall_item_count = 0;
	$floor_wall_item_count = 0;
	$garden_item_count = 0;
	$error_item_count = 0;
	$error = false;
	$user = $users[$i]['user_id'];

	// Check if user has created an ADR character or not
	$sql = "SELECT character_id, character_race, character_class, character_alignment, character_element FROM  " . ADR_CHARACTERS_TABLE . "
			WHERE character_id = $user ";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(CRITICAL_ERROR, 'Error checking if user has character');
	}
	$row = $db->sql_fetchrow($result);

	if ( !$row['character_id'] || !$row['character_race'] || !$row['character_class'] || !$row['character_alignment'] || !$row['character_element'] )
	{
		$adr_character = false;
	}
	else
	{
		$adr_character = true;
	}

	If ( strlen($users[$i]['user_items']) > 2 &&  $adr_character && strlen($users[$i]['house_inventory']) > 2 )
	{
		$item_first_pass = str_replace("�", "", $users[$i]['user_items']);
		$item_second_pass = explode('�',$item_first_pass);
echo '<br />User Item Count1 = ' . count($item_second_pass);
		$inventoryarray = explode(',',$users[$i]['house_inventory']);
		for ($iv = 0; $iv <= count($inventoryarray); $iv++)
		{
			if ($inventoryarray[$iv] != '')
			{
    	        $item_second_pass[] = $inventoryarray[$iv];
			}
		}
// echo '<br />User Item Count2 = ' . count($item_second_pass);

		for ( $t = 0 ; $t < count($item_second_pass) ; $t++ )
		{
			// Determine the new start id for the items
			$sql = "SELECT item_id
					FROM ". ADR_SHOPS_ITEMS_TABLE ."
					WHERE item_owner_id = '$user'
					ORDER BY item_id
					DESC LIMIT 1";
			$result = $db->sql_query($sql);
			if (!$result)
				message_die(GENERAL_ERROR, 'Could not obtain ADR item information', '', __LINE__, __FILE__, $sql);
			$data = $db->sql_fetchrow($result);

			$new_item_id = $data['item_id'] + 1;

			$isql = "SELECT * FROM phpbb_shopitems
					WHERE name = '$item_second_pass[$t]'
						AND ( furniture_type='1' OR furniture_type='2' OR furniture_type='3' OR furniture_type='4' )
					ORDER by name";

			if( !($iresult = $db->sql_query($isql) ))
			{
				message_die(GENERAL_ERROR, 'Could not obtain users information', "", __LINE__, __FILE__, $isql);
			}
			$item = $db->sql_fetchrow($iresult);

			$name = addslashes(stripslashes($item['sdesc']));
			$price = $item['cost'];
			$type = $item['furniture_type'];
			$desc = addslashes(stripslashes($item['ldesc']));
//			$quality = rand(1,5);

			$item_type		= $type + 71;
			if ( $item_type == 72 )
			{
				$floor_item_count = $floor_item_count + 1;
				$total_floor_item_count = $total_floor_item_count + 1;
			}
			else if  ( $item_type == 73 )
			{
				$wall_item_count = $wall_item_count + 1;
				$total_wall_item_count = $total_wall_item_count + 1;
			}
			else if  ( $item_type == 74 )
			{
				$floor_wall_item_count = $floor_wall_item_count + 1;
				$total_floor_wall_item_count = $total_floor_wall_item_count + 1;
			}
			else if  ( $item_type == 75 )
			{
				$garden_item_count = $garden_item_count + 1;
				$total_garden_item_count = $total_garden_item_count + 1;
			}
			else
			{
				$error_item_count = $error_item_count + 1;
				$total_error_item_count = $total_error_item_count + 1;
				$error = true;
			}

			$icon = 'house/' . $item_second_pass[$t] . '.gif';
//echo '<br /><font color="red">Item In House = ' . $item_in_house.'</font>';
//echo '<br />Item Owner = ' . $user;
//echo '<br />Item Icon = ' . $icon;
			If ( $item_type )
			{
//echo "<br />Item ID=".$new_item_id."<br />Owner=".$user."<br />Item Type=".$item_type." / ".$type."<br />Item Desc=".$name."<br />Item Name=".$item_second_pass[$t];
				$sql = "INSERT INTO " . ADR_SHOPS_ITEMS_TABLE . "
						( item_id , item_owner_id , item_type_use , item_name , item_desc , item_icon , item_price , item_duration )
						VALUES ( $new_item_id , $user , $item_type , '" . str_replace("\'", "''", $name) . "', '" . str_replace("\'", "''", $desc) . "' , '" . str_replace("\'", "''", $icon) . "' , $price , 1 )";
				$result = $db->sql_query($sql);
//				if( !$result = $db->sql_query ($sql) )
//				{
//					$error = $db->sql_error();
//				}
			}
		}
		$template->assign_block_vars('users', array(
			'L_ITEMS_PROCESSED' => 'The following User Shop MOD items were processed for ' . $users[$i]['username'] . ':',
			'L_FLOOR_ITEMS_COUNT' => ( $floor_item_count > 0 ) ? 'We processed ' . number_format($floor_item_count) . ' Floor Items for ' . $users[$i]['username'] : '',
			'L_WALL_ITEMS_COUNT' => ( $wall_item_count > 0 ) ? 'We processed ' . number_format($wall_item_count) . ' Wall Items for ' . $users[$i]['username'] : '',
			'L_FLOOR_WALL_ITEMS_COUNT' => ( $floor_wall_item_count > 0 ) ? 'We processed ' . number_format($floor_wall_item_count) . ' Floor Base Of Wall Items for ' . $users[$i]['username'] : '',
			'L_GARDEN_ITEMS_COUNT' => ( $garden_item_count > 0 ) ? 'We processed ' . number_format($garden_item_count) . ' Garden Items for ' . $users[$i]['username'] : '',
			'L_ERROR_ITEMS_COUNT' => ( $error_item_count > 0 ) ? 'We Didn\'t process ' . number_format($error_item_count) . ' Non-House Items for ' . $users[$i]['username'] : '',
		));
	}
}
// End Convert House MOD User Items from Shop MOD Items to ADR Shop Items

// Start Update of User House Table from Shop MOD to ADR Shop
$sql = "SELECT u.username , h.owner_id , h.house_inventory FROM " . USERS_TABLE . " u
		LEFT JOIN " . USER_HOUSE_TABLE . " h ON ( user_id = owner_id )
		WHERE user_id > 1 ";
if( !($cresult = $db->sql_query($csql) ))
{
	message_die(GENERAL_ERROR, 'Could not obtain users information', "", __LINE__, __FILE__, $csql);
}
$users = $db->sql_fetchrowset($cresult);

for ( $i = 0 ; $i < count($users) ; $i ++ )
{
	$inventoryarray = explode(',',$users[$i]['house_inventory']);
	$inventoryamount = count ($inventoryarray);

	$owner_id = $users[$i]['owner_id'];

	$inventory = '';
	for ($a = 0; $a < $inventoryamount; $a++)
	{
		( strlen($inventoryarray[$a]) > 0 ) ? $inventory .= 'house/' . $inventoryarray[$a].',' : $inventory .= $inventoryarray[$a].',' ;

		( strlen($inventoryarray[$a]) > 0 ) ? $item_add = 'house/' . $inventoryarray[$a] . '.gif' : $item_add = '' ;
		if ( strlen($inventoryarray[$a]) > 0 )
		{
			$sql = "SELECT *
					FROM ". ADR_SHOPS_ITEMS_TABLE ."
					WHERE item_owner_id='$owner_id'
						AND item_in_house = 0
						AND item_icon = '$item_add'";
			$result = $db->sql_query($sql);
			if (!$result)
				message_die(GENERAL_ERROR, 'Could not obtain ADR item information', '', __LINE__, __FILE__, $sql);
			$data = $db->sql_fetchrowset($result);

			$gen_item_id = $data[0]['item_id'];

			$sql = "UPDATE ".ADR_SHOPS_ITEMS_TABLE."
					SET item_in_house = 1
					WHERE item_owner_id='$owner_id'
						AND item_id = '". $gen_item_id ."'";
			if ( !($result = $db->sql_query($sql)) ) { message_die(GENERAL_MESSAGE, 'Fatal Error Updating Shop Data!'); }
// echo '<br />Data = ' . $data[0]['item_id'];
// echo '<br />Item ID = ' . $gen_item_id;
// echo '<br />Item Icon = ' . $item_add;
		}

	}

	$sql = "UPDATE ".USER_HOUSE_TABLE." SET house_inventory='$inventory' WHERE owner_id='$owner_id'";
	if ( !($result = $db->sql_query($sql)) ) { message_die(GENERAL_MESSAGE, 'Fatal Error Updating Userhouse!'); }
}
// End Update of User House Table from Shop MOD to ADR Shop


$template->assign_vars(array(
	'L_USER_PROCESSING_COMPLETE' => 'All Users Shop MOD Items processed.',
	'L_TOTAL_FLOOR_ITEMS_COUNT' => ( $total_floor_item_count > 0 ) ? 'We processed ' . number_format($total_floor_item_count) . ' Floor Items' : '',
	'L_TOTAL_WALL_ITEMS_COUNT' => ( $total_wall_item_count > 0 ) ? 'We processed ' . number_format($total_wall_item_count) . ' Wall Items' : '',
	'L_TOTAL_FLOOR_WALL_ITEMS_COUNT' => ( $total_floor_wall_item_count > 0 ) ? 'We processed ' . number_format($total_floor_wall_item_count) . ' Floor Base Of Wall Items' : '',
	'L_TOTAL_GARDEN_ITEMS_COUNT' => ( $total_garden_item_count > 0 ) ? 'We processed ' . number_format($total_garden_item_count) . ' Garden Items' : '',
	'L_TOTAL_ERROR_ITEMS_COUNT' => ( $total_error_item_count > 0 ) ? 'We didn\'t process ' . number_format($total_error_item_count) . ' Non-House Items' : '',
));

//
// Start output of page
//

//
// Generate the page
//
$template->pparse('body');

include($phpbb_root_path . 'includes/page_tail.' . $phpEx);

?>
