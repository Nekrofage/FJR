cp *.png ../../../images/map_maps/
